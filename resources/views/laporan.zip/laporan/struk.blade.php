<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <img src="{{url('/images/header_laporannew.png')}}" alt="Image">
        <br>
        <span style="font-weight: bold;">-----------------g---------------------------------------------</span>
        <h3 style="margin-right: 450px;">Receipt #</h3>
        <span>ferfef</span>
        <h3 class="print">Printed by www</h3>
        <br>
        <span >-----------------g---------------------------------------------</span>
        <span>....................................</span>
        <h2>FUN PLACE TO GRILL</h2>
        <span>....................................</span>
    </div>
</body>

<style>
    .container {
        text-align: center;
    }
    
</style>
</html>