<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <img src="<?php echo e(url('/images/header_laporannew.png')); ?>" alt="Image">
        <br>
        <h4 class="fw-bold">--------------------------------------------------------</h4>
        <!-- <h5 class="fw-bold" style="margin-right: 450px;">Receipt #</h5>
        <span>ferfef</span>
        <h3 class="print">Printed by www</h3>
        <div class="container overflow-hidden"> -->
        <div class="row row-cols-2 px-5">
            <div class="col text-end"><span class="fw-bold">Reeceipt # </span>AKB-040421-50</div>
            <div class="col text-start"><span class="fw-bold">Date </span>04/01/2012</div>
            <div class="col text-start"><span class="fw-bold">Waiter </span>Boy</div>
            <div class="col text-end"><span class="fw-bold">Time </span>14.55</div>
        </div>
    </div>
</body>

<style>
    .container {
        text-align: center;
    }
    
</style>
</html><?php /**PATH D:\xampp\htdocs\P3L\p3l_backend\resources\views/laporan/struk.blade.php ENDPATH**/ ?>