<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container text-center">
        <h3>HAHAHAHAHA</h3>
        <div>            
            <img src="data:image/svg;base64, <?php echo e($qrcode); ?> ">
        </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\P3L\p3l_backend\resources\views/qrcode/qr.blade.php ENDPATH**/ ?>