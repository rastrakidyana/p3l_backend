<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <img src="<?php echo e(url('/images/logo_akb.png')); ?>" alt="Image" width="300" height="300">        
        <div>            
            <img src="data:image/svg;base64, <?php echo e($qrcode); ?> ">
        </div>
        <h3>Printed <?php echo e($date); ?>, <?php echo e($thn); ?> <?php echo e($jam); ?></h3>
        <h3 class="print">Printed by <?php echo e($orang); ?></h3>
        <br>
       
        <span>....................................</span>
        <h2>FUN PLACE TO GRILL</h2>
        <span>....................................</span>
    </div>
</body>

<style>
    .container {
        text-align: center;
    }
    .print {
        font-weight: normal;
    }
</style>
</html><?php /**PATH /home/atmakor3/public_html/resources/views/qrcode/qr.blade.php ENDPATH**/ ?>