<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous" media='all'>
    <title>Document</title>
</head>
<body>
    <div class="container">
        <img src="{{url('/images/header_laporannew.png')}}" alt="Image">
        <h2>------------------------------------------------------------------------</h2>
    </div>
</body>

<style>
    .container {
        text-align: center;
    }
    
</style>
</html>